# colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (50, 205, 50)

# scale
SCALE = 64

# screen size
SCREEN_HEIGHT = 480
SCREEN_WIDTH = 640